# Image source folder

Drop your 4 original PNGs into the matching question folder:

```
images-source/q01/
  1.png      # any of png / jpg / jpeg / webp
  2.png
  3.png
  4.png
```

Then run:

```
npm run images
```

This resizes each PNG to max 1280px wide and writes a `.webp` (~70% quality)
to `public/questions/qNN/N.webp`. Those optimized files are what the app loads
in the browser — keeps things snappy on flaky wifi at the venue.

The optimizer is idempotent: it only re-encodes files whose source has
changed since the last build.

`npm run build` runs this automatically before `vite build`, so deploys
always carry the latest optimized images.
